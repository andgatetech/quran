<?php $__env->startSection('content'); ?>
<header class="header">
    <a class="back-btn" href="<?php echo e(route('client.menu')); ?>"><i class="fas fa-home"></i></a>
    <h1> Curriculum List</h1>
</header>

<div class="tabs">
    <style>
        .tab-btn {
            float: left;
            border-radius: 30px;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s;
            width: 45% !important;
            padding: .3rem 0;
            margin: .5rem .2rem;
        }
    </style>
    <button class="tab-btn" onclick="window.location.href='<?php echo e(route('curriculum.create')); ?>'">Create Curriculum</button>
    <button class="tab-btn active" onclick="window.location.href='<?php echo e(route('curriculum.index')); ?>'">Curriculum List</button>
</div>

<style>
    .container {
        width: 100%;
        max-width: 100%;
        text-align: center;
        margin: 0 auto;
    }
    .list-container {
        display: inline-block;
        width: 100%;
        max-width: 100%;
        text-align: center;
        margin: 0 auto;
        min-height: 20rem !important;
        max-height: 60rem !important;
        margin: 0 0 6vw 0;
    }
    .list-item.active .question-header i {
        transform: rotate(180deg);
        transition: transform 0.3s ease-in-out;
    }
    .details strong  { color: black }
    .details p { color: var(--secondary-color) !important; margin: 0; }
    .list-item { padding: .4rem !important; }
</style>

<div class="container my-5">
    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Error Message -->
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <!-- Curriculum List -->
    <div class="list-container">
        <?php $__empty_1 = true; $__currentLoopData = $curriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="list-item mb-3 p-3 border rounded" onclick="this.classList.toggle('active')">
                <div class="question-header">
                    <span><strong><?php echo e($curriculum->title); ?></strong></span>
                    <i class="fas fa-chevron-down"></i>
                </div>

                <div class="details mt-2" style="display: none;">
                    <p><strong>Competition:</strong> <?php echo e($curriculum->competition->main_name); ?></p>
                    <p><strong>Side Category:</strong> <?php echo e($curriculum->sideCategory->name); ?></p>
                    <p><strong>Read Category:</strong> <?php echo e($curriculum->readCategory->name); ?></p>
                    <p><strong>Age Category:</strong> <?php echo e($curriculum->ageCategory->name); ?></p>
                    <p><strong>Number of Questions:</strong> <?php echo e($curriculum->number_of_questions); ?></p>
                    <p><strong>Total Ayah:</strong> <?php echo e($curriculum->total_ayah); ?></p>
                    <p><strong>Remarks:</strong> <?php echo e($curriculum->remarks ?? 'N/A'); ?></p>
                    <div class="button-group-inline mt-3">
                        <a href="<?php echo e(route('curriculum.edit', $curriculum->id)); ?>" class="btn btn-edit btn-warning">Edit</a>
                        <form action="<?php echo e(route('curriculum.destroy', $curriculum->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-delete btn-danger" onclick="return confirm('Are you sure you want to delete this curriculum?')">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No curriculums found.</p>
        <?php endif; ?>
    </div>
</div>

<!-- JavaScript to toggle details -->
<script>
    document.querySelectorAll('.list-item').forEach(item => {
        item.addEventListener('click', function(e) {
            // Prevent toggling when clicking on buttons
            if (e.target.tagName.toLowerCase() !== 'button' && e.target.tagName.toLowerCase() !== 'a') {
                this.querySelector('.details').style.display = this.classList.contains('active') ? 'block' : 'none';
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u219652911/domains/ncomp.site/public_html/new.ncomp/resources/views/client/curriculum/list.blade.php ENDPATH**/ ?>