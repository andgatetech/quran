<?php $__env->startSection('content'); ?>




<header class="header">
    <a class="back-btn" href="<?php echo e(route('client.menu')); ?>"><i class="fas fa-home"></i></a>
    <h1> Create Sponsor</h1>
  </header>

<div class="tabs">

<button class="tab-btn active"  onclick="window.location.href='<?php echo e(route('sponsors.create')); ?>'">Create Sponsor</button>
<button class="tab-btn " onclick="window.location.href='<?php echo e(route('sponsors.index')); ?>'">Sponsor List</button>
</div>




    <div class="container">



        <!-- The Form -->
        <form action="<?php echo e(route('sponsors.store')); ?>" method="POST" enctype="multipart/form-data" class="form-container mt-4">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <input type="text" class="form-control" name="name" placeholder="Sponsor Name" value="<?php echo e(old('name')); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="competition_id" class="form-label">Competition</label>
                <select class="form-control" id="competition_id" name="competition_id" required>
                    <option value="">Select Competition</option>
                    <?php $__currentLoopData = $competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($competition->id); ?>" <?php echo e(old('competition_id') == $competition->id ? 'selected' : ''); ?>>
                            <?php echo e($competition->main_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>

            <div class="form-group mb-3">
                <input type="text" class="form-control" name="Tin" placeholder="Tin# / ID" value="<?php echo e(old('Tin')); ?>" >
            </div>

            <div class="form-group mb-3">
                <input type="text" class="form-control" name="Details" placeholder="Details" value="<?php echo e(old('Details')); ?>" >
            </div>

            <div class="form-group mb-3">
                
                <select class="form-control" id="status" name="status" required>
                    <option value="">Slider Option (Enable/Disable) </option>
                        <option value="Enable">Enable</option>
                        <option value="Disable">Disable</option>

                  
                </select>

            </div>


            <div class="form-group mb-3">
                <label for="logo" class="form-label">Sponsor Logo</label>
                <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u219652911/domains/ncomp.site/public_html/new.ncomp/resources/views/client/sponsor/create.blade.php ENDPATH**/ ?>