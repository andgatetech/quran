<?php $__env->startSection('content'); ?>




<header class="header">
    <a class="back-btn" href="<?php echo e(route('client.menu')); ?>"><i class="fas fa-home"></i></a>
    <h1>Create Curriculum</h1>
  </header>

  <div class="container1">
<div class="tabs">

<button class="tab-btn active"  onclick="window.location.href='<?php echo e(route('curriculum.create')); ?>'">Create curriculum</button>
<button class="tab-btn " onclick="window.location.href='<?php echo e(route('curriculum.index')); ?>'">curriculum List</button>
</div>
  </div>




    <div class="container my-5">


        <!-- Success Message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Error Message -->
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <!-- Validation Errors -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- The Form -->
        <form action="<?php echo e(route('curriculum.store')); ?>" method="POST" class="form-container" style="margin: 0 !important;">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <input type="text" class="form-control" name="title" placeholder="Title" value="<?php echo e(old('title')); ?>" required>
                
            </div>

            <div class="form-group mb-4">
                <select class="form-control" id="number_of_questions" name="number_of_questions" required>
                    <option value="">Select Quran Option by (Book or Surah)</option>
                    <option value="1" <?php echo e(old('quran_option') == 1 ? 'selected' : ''); ?>>Alif Lam Meem</option>
                    <option value="2" <?php echo e(old('quran_option') == 2 ? 'selected' : ''); ?>>Sayaqool</option>
                    <option value="3" <?php echo e(old('quran_option') == 3 ? 'selected' : ''); ?>>Alif Lam</option>
                    <option value="4" <?php echo e(old('quran_option') == 4 ? 'selected' : ''); ?>>Meem</option>
                </select>
            </div>
            
            <div class="form-group mb-4">
                <select class="form-control" id="number_of_questions" name="number_of_questions" required>
                    <option value="">Select Multiple number of book or Surah</option>
                    <option value="1" <?php echo e(old('quran_option') == 1 ? 'selected' : ''); ?>>Alif Lam Meem</option>
                    <option value="2" <?php echo e(old('quran_option') == 2 ? 'selected' : ''); ?>>Sayaqool</option>
                    <option value="3" <?php echo e(old('quran_option') == 3 ? 'selected' : ''); ?>>Alif Lam</option>
                    <option value="4" <?php echo e(old('quran_option') == 4 ? 'selected' : ''); ?>>Meem</option>
                </select>
            </div>
            
            <div class="form-group mb-3">
                <label for="total_ayah">Total # of Ayah : </label>
                <input type="text" class="form-control" name="total_ayah" value="1235" readonly>
            </div>
            
            
            

            <div class="form-group mb-3">
                <select class="form-control" id="competition_id" name="competition_id" required>
                    <option value="">Select Competition</option>
                    <?php $__currentLoopData = $competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($competition->id); ?>" <?php echo e(old('competition_id') == $competition->id ? 'selected' : ''); ?>>
                            <?php echo e($competition->main_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
            <div class="form-group mb-3">
                <select class="form-control" id="side_category_id" name="side_category_id" required>
                    <option value="">Select Side Category</option>
                    <?php $__currentLoopData = $sideCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sideCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sideCategory->id); ?>" <?php echo e(old('side_category_id') == $sideCategory->id ? 'selected' : ''); ?>>
                            <?php echo e($sideCategory->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value="1">Default</option>


                </select>
            </div>
            <div class="form-group mb-3">
                <select class="form-control" id="read_category_id" name="read_category_id" required>
                    <option value="">Select Read Category</option>
                    <?php $__currentLoopData = $readCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $readCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($readCategory->id); ?>" <?php echo e(old('read_category_id') == $readCategory->id ? 'selected' : ''); ?>>
                            <?php echo e($readCategory->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value="1">Default</option>


                </select>
            </div>
            <div class="form-group mb-3">
                <select class="form-control" id="age_category_id" name="age_category_id" required>
                    <option value="">Select Age Category</option>
                    
                                        <option value="1">Default</option>


                </select>
            </div>
            

            <div class="form-group mb-3">
                <label for="remarks">Remarks (optional):</label>
                <textarea class="form-control" name="remarks" id="remarks" rows="4" placeholder="Enter your remarks here..."></textarea>
            </div>
            

            <button type="submit" class="btn btn-primary">Save</button>
        </form>


        <hr>


    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u219652911/domains/ncomp.site/public_html/new.ncomp/resources/views/client/curriculum/create.blade.php ENDPATH**/ ?>