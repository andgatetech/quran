<?php $__env->startSection('content'); ?>
    <style>
        .container1 {
            margin: 2rem 0 !important;
        }
        .container {margin-bottom: 6rem}


        .button-group1 {
            display: block;
            gap: 10px;
            margin-bottom: 20px;
        }

        .button-group1 .btn {
            float: left;

            border-radius: 30px;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s;
            width: 45% !important;
            padding: .3rem 0;
            margin: .5rem .2rem;
        }
/* .{font-size: .9rem !important} */

.button-group1 .btn{color: var(--secondary-color) ;
    border:1px solid var(--secondary-color) ;
    }


.active-button{    background-color: var(--secondary-color) !important;
    color: #ffffff !important;

}
.button-group1 a:hover{background-color: var(--secondary-color) !important;
    color: #ffffff !important;}





    .question-header i {
            color: #888;
            transition: transform 0.3s;
        }

        .list-item.active .question-header i {
            transform: rotate(180deg);
        }

        .rankstatus{font-size: .8rem;}
        .rankstatus p {display: inline !important;}
        .rankstatus1{color: red}

        .list-container {
    max-height: 100% !important;
    overflow-y: auto;
    padding: 10px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1) ;
    /* box-shadow: none !important;; */
    margin-bottom: 20px;

}




.btn-complete,
        .btn-result {
            border-radius: 5px;
            font-size: 14px;
            padding: 10px 20px;
            cursor: pointer;
        }

        .btn-complete {
            background-color: var(--secondary-color);
            color: white;
        }

        .btn-result {
            background-color: #007bff;
            color: white;
        }

        .btn-result:hover {
            background-color: #0056b3;
        }

        .btn-complete:hover {
            background-color: #008f79;
        }


    </style>
    <header class="header">
        <a class="back-btn" href="<?php echo e(route('client.menu')); ?>"><i class="fas fa-home"></i></a>
         Announce Winners
    </header>
    <div class="button-group1">
        <a href="<?php echo e(route('host.create')); ?>" class="btn  ">Host Competition</a>
        <a href="<?php echo e(route('competitions.list')); ?>" class="btn  active-button">Competitions</a>
        <a href="<?php echo e(route('host.announce')); ?>" class="btn  ">Announce Winners</a>
    </div>
    <div class="container">
        <div class="list-container">
            <?php $__currentLoopData = $hosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $host): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-item mb-3 p-3 border rounded" onclick="this.classList.toggle('active')">
                <div class="question-header">
                    <p><strong>Main Name:</strong> <span><?php echo e($host->main_name); ?></span><i class="fas fa-chevron-down"></i></p>
                </div>
                <div class="details">
                    <p><strong>Competition Sub Name:</strong> <?php echo e($host->sub_name); ?></p>
                    <p><strong>Host ID:</strong> <?php echo e($host->host_id); ?></p>
                    <p><strong>Password:</strong> **********</p>
                    <?php if($host->status == 'active'): ?>
                    <p><strong>Host Date:</strong> <?php echo e(\Carbon\Carbon::parse($host->created_at)->format('d-m-Y')); ?></p>
                    <div class="button-group-inline">
                        <form action="<?php echo e(route('host.continue', $host->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-complete">Continue</button>
                        </form>
                        <form action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-result">Result</button>
                        </form>
                    </div>
                    <?php elseif($host->status == 'done'): ?>
                    <p><strong>Host Date:</strong> <?php echo e(\Carbon\Carbon::parse($host->created_at)->format('d-m-Y')); ?></p>
                    <p><strong>Completed Date:</strong> <?php echo e(\Carbon\Carbon::parse($host->updated_at)->format('d-m-Y')); ?></p>
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-result">Result</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u219652911/domains/ncomp.site/public_html/resources/views/client/host/competition-list.blade.php ENDPATH**/ ?>