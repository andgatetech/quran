<?php $__env->startSection('content'); ?>


<header class="header">
    <a class="back-btn" href="<?php echo e(route('client.menu')); ?>"><i class="fas fa-home"></i></a>
    <h1> View Sponsor</h1>
  </header>

  <div class="container1">
<div class="tabs">
<button class="tab-btn "  onclick="window.location.href='<?php echo e(route('sponsors.create')); ?>'">Create Sponsor</button>
<button class="tab-btn " onclick="window.location.href='<?php echo e(route('sponsors.index')); ?>'">Sponsor List</button>
</div>
  </div>


    <div class="container my-5" style="margin-bottom:6rem !important;">


        <!-- Sponsor Details -->
        <div class="card">
            <div class="card-header">
                <?php echo e($sponsor->name); ?>

            </div>
            <div class="card-body">
                <p><strong>Competition:</strong> <?php echo e($sponsor->competition->name); ?></p>
                <?php if($sponsor->logo): ?>
                    <p><strong>Logo:</strong></p>
                    <img src="<?php echo e(asset('public/'.$sponsor->logo)); ?>" alt="Sponsor Logo" width="150">
                <?php else: ?>
                    <p><strong>Logo:</strong> Not Uploaded</p>
                <?php endif; ?>
                <p><strong>Created At:</strong> <?php echo e($sponsor->created_at->format('Y-m-d')); ?></p>
                <p><strong>Updated At:</strong> <?php echo e($sponsor->updated_at->format('Y-m-d')); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/new.ncomp/resources/views/client/sponsor/view.blade.php ENDPATH**/ ?>