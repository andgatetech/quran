<?php $__env->startSection('content'); ?>
<header class="header">
    <a class="back-btn" href="<?php echo e(route('client.menu')); ?>"><i class="fas fa-home"></i></a>
    <h1> Competitor List</h1>
  </header>

<div class="tabs">
    <style>
              .tab-btn {
   float: left;

    border-radius: 30px;
    font-size: 16px;
    transition: background-color 0.3s, color 0.3s;
    width: 45% !important;
    padding: .3rem 0;
    margin: .5rem .2rem;
}
    </style>
<button class="tab-btn "  onclick="window.location.href='<?php echo e(route('competitors.create')); ?>'">Create Competitor</button>
<button class="tab-btn active" onclick="window.location.href='<?php echo e(route('competitors.index')); ?>'">Competitor List</button>
</div>


  <style>
     .container {
        /* flex-grow: 1; */
        /* Make the container take up the available space between header and footer */
        width: 100%;
        max-width: 100%;
        /* Full width for container */
        text-align: center;
        margin: 0 auto;
        /* Center the container horizontally */

    }

    .list-container {
        display: inline-block;
        width: 100%;
        max-width: 100%;
        /* Full width for container */
        text-align: center;
        margin: 0 auto;
        min-height: 20rem !important;
        max-height: 60rem !important;
        margin: 0 0 6vw 0;


    }
    .list-item.active .question-header i {
    transform: rotate(180deg);  /* Rotates the arrow icon */
    transition: transform 0.3s ease-in-out;
}
.details strong  {color: black}
.details p  {
        color: var(--secondary-color) !important;
        margin: 0;
    }
    .list-item{padding: .4rem !important;}

</style>

    <div class="container my-5">

        <!-- Success Message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Error Message -->
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <!-- Competitor List -->
        <div class="list-container">
            
            <?php $__empty_1 = true; $__currentLoopData = $competitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="list-item mb-3 p-3 border rounded" onclick="this.classList.toggle('active')">


                        <div class="question-header">
                            <span><strong> <?php echo e($competitor->full_name); ?></strong> (<?php echo e($competitor->id_card_number); ?>)</span>
                            <i class="fas fa-chevron-down"></i>
                        </div>









                    <div class="details mt-2" style="display: none;     box-shadow:0 !important;">
                        <p><strong>ID Card Number:</strong> <?php echo e($competitor->id_card_number); ?></p>
                        <p><strong>Address:</strong> <?php echo e($competitor->address); ?></p>
                        <p><strong>Island / City:</strong> <?php echo e($competitor->island_city); ?></p>
                        <p><strong>School:</strong> <?php echo e($competitor->school_name ?? 'N/A'); ?></p>
                        <p><strong>Parent:</strong> <?php echo e($competitor->parent_name); ?></p>
                        <p><strong>Phone Number:</strong> <?php echo e($competitor->phone_number); ?></p>
                        <p><strong>Competition Name:</strong> <?php echo e($competitor->competition->main_name); ?></p>
                        <p><strong>Side Category:</strong> <?php echo e($competitor->sideCategory->name); ?></p>
                        <p><strong>Read Category:</strong> <?php echo e($competitor->readCategory->name); ?></p>
                        <p><strong>Age Category:</strong> <?php echo e($competitor->ageCategory->name); ?></p>
                        <p><strong>Number of Questions:</strong> <?php echo e($competitor->number_of_questions); ?></p>
                        <div class="button-group-inline mt-3">
                            <a href="<?php echo e(route('competitors.edit', $competitor->id)); ?>" class="btn btn-edit btn-warning">Edit</a>
                            <form action="<?php echo e(route('competitors.destroy', $competitor->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-delete btn-danger" onclick="return confirm('Are you sure you want to delete this competitor?')">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No competitors found.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- JavaScript to toggle details -->
    <script>
        document.querySelectorAll('.list-item').forEach(item => {
            item.addEventListener('click', function(e) {
                // Prevent toggling when clicking on buttons
                if (e.target.tagName.toLowerCase() !== 'button' && e.target.tagName.toLowerCase() !== 'a') {
                    this.querySelector('.details').style.display = this.classList.contains('active') ? 'block' : 'none';
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u219652911/domains/ncomp.site/public_html/resources/views/client/competitor/list.blade.php ENDPATH**/ ?>