<?php $__env->startSection('content'); ?>
    <style>
        .container1 {
            margin: 2rem 0 !important;
        }
        .container {margin-bottom: 6rem}


        .button-group1 {
            display: block;
            gap: 10px;
            margin-bottom: 20px;
        }

        .button-group1 .btn {
            float: left;

            border-radius: 30px;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s;
            width: 45% !important;
            padding: .3rem 0;
            margin: .5rem .2rem;
        }
/* .{font-size: .9rem !important} */

.button-group1 .btn{color: var(--secondary-color) ;
    border:1px solid var(--secondary-color) ;
    }


.active-button{    background-color: var(--secondary-color) !important;
    color: #ffffff !important;

}
.button-group1 a:hover{background-color: var(--secondary-color) !important;
    color: #ffffff !important;}





    .question-header i {
            color: #888;
            transition: transform 0.3s;
        }

        .list-item.active .question-header i {
            transform: rotate(180deg);
        }

        .rankstatus{font-size: .8rem;}
        .rankstatus p {display: inline !important;}
        .rankstatus1{color: red}
    </style>
    <header class="header">
        <a class="back-btn" href="<?php echo e(route('client.menu')); ?>"><i class="fas fa-home"></i></a>
         Announce Winners
    </header>
    <div class="button-group1">
        <a href="<?php echo e(route('host.create')); ?>" class="btn  ">Host Competition</a>
        <a href="<?php echo e(route('competitions.list')); ?>" class="btn  ">Competitions</a>
        <a href="<?php echo e(route('host.announce')); ?>" class="btn  active-button">Announce Winners</a>
    </div>

    <div class="button-group1" style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px; border-radius:1rem;padding:.5rem; border:1px solid  var(--secondary-color);">
        <select id="sideCategoryFilter" class="btn ">
            <option value="">Select Side Category</option>
            <?php $__currentLoopData = $sideCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sideCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($sideCategory->id); ?>"><?php echo e($sideCategory->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select id="readCategoryFilter" class="btn ">
            <option value="">Select Read Category</option>
            <?php $__currentLoopData = $readCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $readCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($readCategory->id); ?>"><?php echo e($readCategory->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select id="ageCategoryFilter" class="btn ">
            <option value="">Select Age Category</option>
            <?php $__currentLoopData = $ageCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ageCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ageCategory->id); ?>"><?php echo e($ageCategory->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="container">
        <div id="competitorList">
            <?php $__currentLoopData = $sortedCompetitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    // Check if competitor is already ranked
                    $alreadyRanked = \App\Models\Ranking::where('competitor_id', $competitor->id)->exists();

                    $totalPoints = 0;
                    $gainedPoints = 0;
                    foreach ($competitor->results as $result) {
                        $totalPoints += $result->total_points;
                        $gainedPoints += $result->gained_points;
                    }
                ?>

<form action="<?php echo e(route('rank.create', $competitor->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="rank" value="<?php echo e($competitor->position); ?>">
    <div class="question-card"
         data-side-category-id="<?php echo e($competitor->sideCategory->id ?? ''); ?>"
         data-side-category-name="<?php echo e($competitor->sideCategory->name ?? ''); ?>"
         data-read-category-id="<?php echo e($competitor->readCategory->id ?? ''); ?>"
         data-read-category-name="<?php echo e($competitor->readCategory->name ?? ''); ?>"
         data-age-category-id="<?php echo e($competitor->ageCategory->id ?? ''); ?>"
         data-age-category-name="<?php echo e($competitor->ageCategory->name ?? ''); ?>">

        <div class="question-header" onclick="toggleDetails(this)">
            <span><span>Place :</span> <strong><?php echo e($competitor->position); ?></strong></span>


              <span class="rankstatus">Status:

                <?php if(!$alreadyRanked): ?>
                <p class="rankstatus1">Not Sent</p>

                <?php else: ?>
                <p style=" font-weight:100;  ;color:
                <?php if($competitor->ranking->status === 'pending'): ?>
                    blue
                <?php elseif($competitor->ranking->status === 'announced'): ?>
                    green
                <?php endif; ?>;
                text-transform: capitalize;">
                <?php echo e(ucfirst($competitor->ranking->status)); ?>

            </p>

                <?php endif; ?>

                </span>
                            <span class="arrow"><i class="fas fa-chevron-down"></i></span>
        </div>

        <div class="question-details">
            <p><strong>Name :</strong> <span><?php echo e($competitor->full_name); ?></span></p>
            <p><strong>ID Card Number :</strong> <span><?php echo e($competitor->id_card_number); ?></span></p>
            <p><strong>Address :</strong> <span><?php echo e($competitor->address); ?></span></p>
            <p><strong>Island/City :</strong> <span><?php echo e($competitor->island_city); ?></span></p>
            <p><strong>School Name :</strong> <span><?php echo e($competitor->school_name ?? 'N/A'); ?></span></p>
            <p><strong>Parent Name :</strong> <span><?php echo e($competitor->parent_name); ?></span></p>
            <p><strong>Phone Number :</strong> <span><?php echo e($competitor->phone_number); ?></span></p>
            <p><strong>Competition Name :</strong> <span><?php echo e($competitor->competition->main_name ?? 'N/A'); ?></span></p>
            <p><strong>Age Category :</strong> <span><?php echo e($competitor->ageCategory->name ?? 'N/A'); ?></span></p>
            <p><strong>Reading side :</strong> <span><?php echo e($competitor->sideCategory->name ?? 'N/A'); ?></span></p>
            <p><strong>Reading type :</strong> <span><?php echo e($competitor->readCategory->name ?? 'N/A'); ?></span></p>
            <p><strong>Number of Questions :</strong> <span><?php echo e($competitor->number_of_questions); ?></span></p>

            <?php $__currentLoopData = $competitor->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><strong><?php echo e($result->pointCategory->name ?? 'Point Category name'); ?> :</strong>
                    <span><?php echo e($result->total_points); ?>/<?php echo e($result->gained_points); ?></span></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <p><strong>Total # of Point :</strong> <span><?php echo e($totalPoints); ?>/<?php echo e($gainedPoints); ?></span></p>

            <?php if($alreadyRanked): ?>
                <button class="btn btn-secondary" type="button" disabled>Already Sent</button>
            <?php else: ?>
                <button class="btn btn-success send-btn" type="submit">Submit</button>
            <?php endif; ?>
        </div>
    </div>
</form>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <style>
  .question-card {
        background-color: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin: 15px 0;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid #ddd;
    }.question-header {
        background-color: #fff;
        padding: 0.5rem;
        font-size: 1.2em;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        border-bottom: 1px solid #ddd;
    }

    .question-header .arrow {
        cursor: pointer;
        font-size: 1.2em;
        color: #666;
    }

    .question-details {
        padding: 1rem;
        background-color: #fff;
        display: none;
    }

    .question-card.active .question-details {
        display: block;
    }

    .question-details p {
        display: flex;
        justify-content: space-between;
        margin: 5px 0;
        font-size: 14px;
        line-height: 1.5;
        color: #333;
    }

    .question-details p strong {
        flex: 1; /* Align to the left */
        text-align: left;
        font-weight: bold;
        color: #000;
    }

    .question-details p span {
        flex: 1; /* Align to the right */
        text-align: right;
        color: #009f79; /* Dynamic text color */
    }
        .question-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn {
            font-size: 1em;
            padding: 8px 20px;
            border-radius: 5px;
        }

        .send-btn {
            font-size: 1.2em;
            padding: 10px 25px;
            border-radius: 6px;
            background-color: #4CAF50;
            color: var(--primary-color);
            border: none;
            cursor: pointer;
        }

        .send-btn:hover {
            background-color: #45a049;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .send-btn.d-none.d-md-block {
                display: none;
            }
        }
    </style>

    <style>
        .filter-group {
            margin-bottom: 20px;
        }

        .filter-group select {
            margin-right: 15px;
        }


        .btn {
            font-size: 1em;
            padding: 8px 20px;
            border-radius: 5px;
        }

        .send-btn {
            font-size: 1.2em;
            padding: 10px 25px;
            border-radius: 6px;
            background-color: #4CAF50;
            color: var(--primary-color);
            border: none;
            cursor: pointer;
        }

        .send-btn:hover {
            background-color: #45a049;
        }
    </style>
      <style>
        /* Body Styling */
    body {

      background-color: #f9f9f9;
      display: flex;
      flex-direction: column;
      min-height: 100vh; /* Ensure body takes full height of the screen */
      padding: 0; /* Remove default padding */
    }

    /* Container Styling */
    .container {
      flex-grow: 1; /* Allow the content to expand and fill available space */
      padding-bottom: 100px; /* Add space at the bottom for footer */
    }

    /* Footer Styling */
    footer {
      position: fixed;
      bottom: 0;
      left: 0;
      width: 100%;
      /* background-color: #f1f1f1; Footer background color */
      padding: 10px;
      text-align: center;
      margin-bottom: 10px; /* Margin above the footer */
    }

      </style>
      
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        // Filter competitors based on selected criteria
        function filterCompetitors() {
            const sideCategory = document.getElementById('sideCategoryFilter').value.toLowerCase();
            const readCategory = document.getElementById('readCategoryFilter').value.toLowerCase();
            const ageCategory = document.getElementById('ageCategoryFilter').value.toLowerCase();

            // Get all competitor cards
            const competitors = document.querySelectorAll('.question-card');

            competitors.forEach(function(card) {
                // Fetch data attributes
                const cardSideCategoryId = card.getAttribute('data-side-category-id');
                const cardSideCategoryName = card.getAttribute('data-side-category-name').toLowerCase();
                const cardReadCategoryId = card.getAttribute('data-read-category-id');
                const cardReadCategoryName = card.getAttribute('data-read-category-name').toLowerCase();
                const cardAgeCategoryId = card.getAttribute('data-age-category-id');
                const cardAgeCategoryName = card.getAttribute('data-age-category-name').toLowerCase();

                // Determine matches for each category
                const matchesSideCategory = sideCategory ?
                    (cardSideCategoryId == sideCategory || cardSideCategoryName.includes(sideCategory)) :
                    true;
                const matchesReadCategory = readCategory ?
                    (cardReadCategoryId == readCategory || cardReadCategoryName.includes(readCategory)) :
                    true;
                const matchesAgeCategory = ageCategory ?
                    (cardAgeCategoryId == ageCategory || cardAgeCategoryName.includes(ageCategory)) :
                    true;

                // Show or hide the card based on matches
                if (matchesSideCategory && matchesReadCategory && matchesAgeCategory) {
                    card.style.display = 'block'; // Show the card
                } else {
                    card.style.display = 'none'; // Hide the card
                }
            });
        }

        // Add event listeners to dropdowns to filter competitors dynamically
        document.getElementById('sideCategoryFilter').addEventListener('change', filterCompetitors);
        document.getElementById('readCategoryFilter').addEventListener('change', filterCompetitors);
        document.getElementById('ageCategoryFilter').addEventListener('change', filterCompetitors);
    </script>




    <script>
        // Handle Send button click
        function sendCompetitor(competitorId) {
            alert('Competitor with ID ' + competitorId + ' sent!');
            // Here you can send the competitor data to the server via AJAX or redirect as needed
        }

        // Toggle the dropdown and the Send button's position
        function toggleDetails(headerElement) {
            const detailsElement = headerElement.nextElementSibling;
            const sendButton = detailsElement.querySelector('.send-btn');

            if (detailsElement.style.display === "none" || detailsElement.style.display === "") {
                detailsElement.style.display = "block";
                sendButton.classList.remove('d-none');
            } else {
                detailsElement.style.display = "none";
                sendButton.classList.add('d-none');
            }
        }
    </script>
<?php $__env->stopSection(); ?>






















<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/new.ncomp/resources/views/client/host/announce.blade.php ENDPATH**/ ?>