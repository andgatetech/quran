
<style>
      /* Header Styling */
  .header1 {
    background-color: var(--secondary-color);;
    color: var(--primary-color);
    border-radius: 20px;
    margin-bottom: 30px; /* More space below the header */
  }

  .header1 h1 {
    font-size: 24px; /* Increased font size */
    line-height: 1.6;
  }

</style>

<header class="header1">
    <h1>Welcome to,<br>Magey Competition</h1>
  </header>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quran-e/resources/views/includes/welcome-head.blade.php ENDPATH**/ ?>