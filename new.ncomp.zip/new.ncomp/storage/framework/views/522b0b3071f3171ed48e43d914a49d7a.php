<?php $__env->startSection('content'); ?>
<header class="header">
    <a class="back-btn" href="<?php echo e(route('client.menu')); ?>"><i class="fas fa-home"></i></a>
    <h1>Create Questions</h1>
  </header>

<div class="tabs">

<button class="tab-btn active"  onclick="window.location.href='<?php echo e(route('questions.create')); ?>'">Create Question</button>
<button class="tab-btn " onclick="window.location.href='<?php echo e(route('questions.list')); ?>'">Question List</button>
</div>



<div class="container">



















    
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
















        <form id="manualForm" action="<?php echo e(route('questions.store')); ?>" method="POST" class="d-block">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <select class="form-control" id="competition_id" name="competition_id" required>
                    <option value="">Select Competition</option>
                    <?php $__currentLoopData = $competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($competition->id); ?>" <?php echo e(old('competition_id') == $competition->id ? 'selected' : ''); ?>>
                            <?php echo e($competition->main_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>

            <div class="form-group">
                <input type="text" class="form-control" id="question_name" name="question_name" placeholder="Enter Question Name" required />
            </div>

            <div class="form-group mb-3">
                <select class="form-control" id="age_category_id" name="age_category_id" required>
                    <option value="">Select Age Category</option>
                    <?php $__currentLoopData = $ageCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ageCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ageCategory->id); ?>" <?php echo e(old('age_category_id') == $ageCategory->id ? 'selected' : ''); ?>>
                            <?php echo e($ageCategory->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value="1">Default</option>


                </select>
            </div>

            <div class="form-group mb-3">
                <select class="form-control" id="side_category_id" name="side_category_id" required>
                    <option value="">Select Side Category</option>
                    <?php $__currentLoopData = $sideCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sideCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sideCategory->id); ?>" <?php echo e(old('side_category_id') == $sideCategory->id ? 'selected' : ''); ?>>
                            <?php echo e($sideCategory->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value="1">Default</option>


                </select>
            </div>

            <div class="form-group mb-3">
                <select class="form-control" id="read_category_id" name="read_category_id" required>
                    <option value="">Select Read Category</option>
                    <?php $__currentLoopData = $readCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $readCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($readCategory->id); ?>" <?php echo e(old('read_category_id') == $readCategory->id ? 'selected' : ''); ?>>
                            <?php echo e($readCategory->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </select>
            </div>
            




            <div class="form-group">
                <select class="form-control" id="book_number" name="book_number" required>
                    <option value="">Select Book Number</option>
                    <?php $__currentLoopData = range(1, 30); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookNumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bookNumber); ?>">Juz <?php echo e($bookNumber); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- From Ayat Number -->
            <div class="form-group">
                <select class="form-control" id="from_ayat_number" name="from_ayat_number" required>
                    <option value="">Select From Ayah</option>
                </select>
            </div>

            <div class="form-group">
                <select class="form-control" id="to_ayat_number" name="to_ayat_number" required>
                    <option value="">Select To Ayah</option>
                </select>
            </div>




            <div class="form-group">
                <input type="number" class="form-control" id="hardness" name="hardness" placeholder="Hardness of this Question %" min="0" max="100" required />
            </div>

            <button type="submit" class="btn btn-save">Save</button>
        </form>
        <script>
          document.addEventListener('DOMContentLoaded', function () {
    const bookNumberSelect = document.getElementById('book_number');
    const fromAyatSelect = document.getElementById('from_ayat_number');
    const toAyatSelect = document.getElementById('to_ayat_number');

    bookNumberSelect.addEventListener('change', async function () {
        const bookNumber = this.value;

        // Reset dropdowns
        fromAyatSelect.innerHTML = '<option value="">Select From Ayah</option>';
        toAyatSelect.innerHTML = '<option value="">Select To Ayah</option>';

        if (bookNumber) {
            try {
                const response = await fetch(`/api/get-ayahs/${bookNumber}`);
                const data = await response.json();

                if (data.success) {
                    const ayahs = data.ayahs;

                    ayahs.forEach(ayah => {
                        const option = `<option value="${ayah.ayah_no_juzz}">${ayah.ayah_no_juzz}</option>`;
                        fromAyatSelect.innerHTML += option;
                        toAyatSelect.innerHTML += option;
                    });
                } else {
                    alert(data.message || 'Unable to fetch Ayah data.');
                }
            } catch (error) {
                console.error('Error fetching Ayah data:', error);
            }
        }
    });
});


document.addEventListener('DOMContentLoaded', function () {
    const fromAyatSelect = document.getElementById('from_ayat_number');
    const toAyatSelect = document.getElementById('to_ayat_number');

    // Function to validate the Ayah range
    function validateAyahRange() {
        const fromAyah = parseInt(fromAyatSelect.value, 10);
        const toAyah = parseInt(toAyatSelect.value, 10);

        if (fromAyah && toAyah) {
            if (toAyah <= fromAyah) {
                alert('The "To Ayah" must be greater than the "From Ayah".');
                toAyatSelect.value = ''; // Reset the "To Ayah" dropdown
            }
        }
    }

    // Add event listeners to both dropdowns
    fromAyatSelect.addEventListener('change', validateAyahRange);
    toAyatSelect.addEventListener('change', validateAyahRange);
});

        </script>















        <hr>









        <h3 class="mt-5">Bulk Upload Questions</h3>

        <form id="bulkForm" action="<?php echo e(route('questions.bulkUpload')); ?>" method="POST" enctype="multipart/form-data" class="form-container mt-4">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <input type="file" class="form-control" id="bulkFile" name="file" required />
            </div>
            <button type="submit" class="btn btn-save">Upload</button>
        </form>
</div>

<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u219652911/domains/ncomp.site/public_html/resources/views/client/questions/create.blade.php ENDPATH**/ ?>