<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/color.css')); ?>">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Full Width Layout</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap" rel="stylesheet">
    <style>



        .main-content {
            flex: 1; /* Allows the main content to grow and fill available space */
            width: 100%;
            padding: 20px;
        }


        .button-group1 {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .button-group1 .btn {
            border-radius: 30px;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s;
            padding: 10px 20px;
        }

        .active-button {
            background-color: var(--secondary-color);
            color: #ffffff;
        }

        .form-container {
            padding: 15px;
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .form-group label {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 10px;
            display: block;
        }

        .form-control {
            border-radius: 10px;
            padding: 10px;
            font-size: 16px;
            margin-bottom: 20px;
        }

        .btn-submit {
            background-color: var(--secondary-color);
            color: #ffffff;
            border-radius: 10px;
            font-size: 18px;
            padding: 10px 20px;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .header {
                font-size: 22px;
                /* padding: 15px; */
            }

            .button-group1 {
                flex-direction: column;
                gap: 10px;
            }

            .form-container {
                padding: 10px;
            }

            .form-group label {
                font-size: 14px;
            }

            .form-control {
                font-size: 14px;
                padding: 8px;
            }

            .btn-submit {
                font-size: 16px;
                padding: 8px 16px;
            }
        }

        @media (max-width: 480px) {
            .header {
                font-size: 18px;
                padding: 10px;
            }

            .button-group1 {
                flex-direction: column;
                gap: 8px;
            }

            .form-container {
                padding: 8px;
            }

            .form-group label {
                font-size: 12px;
            }

            .form-control {
                font-size: 12px;
                padding: 6px;
            }

            .btn-submit {
                font-size: 14px;
                padding: 6px 12px;
            }
        }



















    .container1{margin-top: 2rem !important;}



    .button-group1 {
    display: block;
    gap: 10px;
    margin-bottom: 20px;
}

.button-group1 .btn {
   float: left;

    border-radius: 30px;
    font-size: 16px;
    transition: background-color 0.3s, color 0.3s;
    width: 45% !important;
    padding: .3rem 0;
    margin: .5rem .2rem;
}


    </style>
</head>
<body>





    <header class="header">
        <a class="back-btn" href="<?php echo e(route('client.menu')); ?>"><i class="fas fa-home"></i></a>
        Create Host
    </header>
    <div class="button-group1">
        <a href="<?php echo e(route('host.create')); ?>" class="btn btn-outline-success active-button">Host Competition</a>
        <a href="<?php echo e(route('competitions.list')); ?>" class="btn btn-outline-success ">Competitions</a>
        <a href="<?php echo e(route('host.announce')); ?>" class="btn btn-outline-success">Announce Winners</a>
    </div>

    <div class="container">


            <div class="form-container">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('host.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    

                    <div class="form-group">
                        <select class="form-control" name="competition_id" id="select-competition">
                            <option value="">Select Competition</option>
                            <?php $__currentLoopData = $competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($competition->id); ?>">
                                    <?php echo e($competition->main_name); ?> - <?php echo e($competition->sub_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['competition_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control" id="competition-sub-name"
                            placeholder="Competition Sub Name (Auto Fill)" readonly>
                    </div>

                    <div class="form-group">
                        <label for="host-id">Host Informations</label>
                        <div class="input-group">
                            <input type="text" class="form-control" name="host_id" id="host-id" placeholder="Host ID" readonly>
                            <div class="input-group-append">
                                <button type="button" class="btn btn-primary" id="generate-host-id" onclick="generateHostId()">Generate</button>
                            </div>
                        </div>
                        <?php $__errorArgs = ['host_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="btn-save btn">On-Air</button>
                </form>
            </div>
        </div>
    

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <script>
        // Function to generate a random host ID
        function generateHostId() {
            const randomId = 'Host_' + Math.random().toString(36).substring(2, 8) + Math.random().toString(36).substring(2, 6);
            document.getElementById('host-id').value = randomId;
        }

        document.addEventListener('DOMContentLoaded', function() {
            const competitionDropdown = document.getElementById('select-competition');
            const competitionSubNameInput = document.getElementById('competition-sub-name');
            const hostIdInput = document.getElementById('host-id');
            const passwordInput = document.getElementById('password');

            competitionDropdown.addEventListener('change', function() {
                // Get the selected competition ID
                const selectedCompetitionId = competitionDropdown.value;

                if (selectedCompetitionId) {
                    // Find the selected competition's details (you could fetch this dynamically if needed)
                    const selectedCompetition =
                    <?php echo json_encode($competitions, 15, 512) ?>; // Converting PHP data to JavaScript
                    const competition = selectedCompetition.find(comp => comp.id == selectedCompetitionId);

                    // Auto-fill the Competition Sub Name input
                    if (competition) {
                        competitionSubNameInput.value = competition.sub_name;
                    }
                } else {
                    competitionSubNameInput.value = ''; // Clear the input if no competition is selected
                }
            });

            // Auto-generate Host ID on page load
            generateHostId();
        });
    </script>

</body>
</html>
<?php /**PATH /home/u219652911/domains/ncomp.site/public_html/resources/views/client/host/create.blade.php ENDPATH**/ ?>