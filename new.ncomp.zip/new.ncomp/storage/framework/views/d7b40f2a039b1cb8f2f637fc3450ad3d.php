<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Dashboard</h2>
    <p>Welcome to the Admin Panel Dashboard!</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u219652911/domains/ncomp.site/public_html/new.ncomp/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>