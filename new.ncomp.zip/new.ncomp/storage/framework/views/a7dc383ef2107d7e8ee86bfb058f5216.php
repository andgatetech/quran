<?php $__env->startSection('content'); ?>


<header class="header">
    <a class="back-btn" href="<?php echo e(route('client.menu')); ?>"><i class="fas fa-home"></i></a>
    <h1> Edit Sponsor</h1>
  </header>

  <div class="container1">
<div class="tabs">
    <style>
              .tab-btn {
   float: left;

    border-radius: 30px;
    font-size: 16px;
    transition: background-color 0.3s, color 0.3s;
    width: 45% !important;
    padding: .3rem 0;
    margin: .5rem .2rem;
}
    </style>
<button class="tab-btn "  onclick="window.location.href='<?php echo e(route('sponsors.create')); ?>'">Create Sponsor</button>
<button class="tab-btn " onclick="window.location.href='<?php echo e(route('sponsors.index')); ?>'">Sponsor List</button>
</div>
  </div>

    <div class="container my-5">

        <!-- Success Message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Error Message -->
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <!-- The Form -->
        <form action="<?php echo e(route('sponsors.update', $sponsor->id)); ?>" method="POST" enctype="multipart/form-data" class="form-container mt-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
        
            <!-- Sponsor Name -->
            <div class="form-group mb-3">
                <input type="text" class="form-control" name="name" placeholder="Sponsor Name"
                       value="<?php echo e(old('name', $sponsor->name)); ?>" required>
            </div>
        
            <!-- Competition Dropdown -->
            <div class="form-group mb-3">
                <label for="competition_id" class="form-label">Competition</label>
                <select class="form-control" id="competition_id" name="competition_id" required>
                    <option value="">Select Competition</option>
                    <?php $__currentLoopData = $competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($competition->id); ?>"
                            <?php echo e(old('competition_id', $sponsor->competition_id) == $competition->id ? 'selected' : ''); ?>>
                            <?php echo e($competition->main_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        
            <!-- Sponsor Logo -->
            <div class="form-group mb-3">
                <label for="logo" class="form-label">Sponsor Logo</label>
                <?php if($sponsor->logo): ?>
                    <p>Current Logo:</p>
                    <img src="<?php echo e(asset('public/'.$sponsor->logo)); ?>" alt="Sponsor Logo" width="150">
                <?php endif; ?>
                <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
            </div>
        
            <!-- Tin -->
            <div class="form-group mb-3">
                <input type="text" class="form-control" name="Tin" placeholder="Tin# / ID"
                       value="<?php echo e(old('Tin', $sponsor->Tin)); ?>">
            </div>
        
            <!-- Details -->
            <div class="form-group mb-3">
                <input type="text" class="form-control" name="Details" placeholder="Details"
                       value="<?php echo e(old('Details', $sponsor->Details)); ?>">
            </div>
        
            <!-- Status -->
            <div class="form-group mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-control" id="status" name="status" required>
                    <option value="Enable" <?php echo e(old('status', $sponsor->status) == 'Enable' ? 'selected' : ''); ?>>Enable</option>
                    <option value="Disable" <?php echo e(old('status', $sponsor->status) == 'Disable' ? 'selected' : ''); ?>>Disable</option>
                </select>
            </div>
        
            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/new.ncomp/resources/views/client/sponsor/edit.blade.php ENDPATH**/ ?>